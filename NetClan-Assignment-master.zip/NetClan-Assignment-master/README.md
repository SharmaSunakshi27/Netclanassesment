# NetClan-Assignment
BlackCoffer Company Assignment

## Multiscreen App
Along with multiscreen, fragments are used to add the functionanlity of the sliding screen.

## Screenshots
![SS1](https://github.com/Harsh5488/NetClan-Assignment/assets/95761669/8d75c56c-3b32-4e66-908b-c8b9a7dd4f35)
</br>
![SS2](https://github.com/Harsh5488/NetClan-Assignment/assets/95761669/77e4013e-2881-4c41-90af-7874cd94a9aa)
